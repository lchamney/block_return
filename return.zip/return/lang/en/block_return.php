<?php
$string['pluginname'] = 'Return block';
$string['return'] = 'Return';
$string['click_to_continue'] = 'Click to continue where you left off.';
$string['returnl:addinstance'] = 'Add a new return block';
$string['return:myaddinstance'] = 'Add a new return block to the My Moodle page';
$string['lightbox'] = 'Display as a lightbox at the bottom of the page.';

?>