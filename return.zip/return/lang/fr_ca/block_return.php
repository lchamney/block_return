<?php
$string['pluginname'] = 'Return block';
$string['return'] = 'Return';
$string['click_to_continue'] = 'Cliquez pour continuer là où vous vous étiez arrêté.';
$string['returnl:addinstance'] = 'Add a new return block';
$string['return:myaddinstance'] = 'Add a new return block to the My Moodle page';
?>